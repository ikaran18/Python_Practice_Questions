i=int(input("Enter a Number :"))

fac=1

while(i>0):
    fac=fac*i
    i=i-1
print("Factorial=",fac)